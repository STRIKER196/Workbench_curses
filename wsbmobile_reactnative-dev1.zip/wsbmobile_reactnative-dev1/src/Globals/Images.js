const images = () => {
    return {
        logo: require( '../../assets/images/logo.png' ),
        loginTransition: require( '../../assets/images/transition.png' ),
        background: require( '../../assets/images/bg.png' ),
    };
};
export default ( new images() );
