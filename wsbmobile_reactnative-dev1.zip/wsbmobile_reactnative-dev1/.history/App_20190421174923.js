import React from 'react';
import { createStore } from 'redux';
import { connect, Provider } from 'react-redux';

import { Text, View } from 'react-native';
import { AppLoading } from 'expo';

import ReduxGlobals from './src/Globals/Redux';

import UserClass from './src/Classes/User';

import LoginView from './src/Views/Login';


export default class App extends React.Component {
  state = {
    isReady: false,
    showLoginScreen: true
  };

  autoLoginUser = async () => {

    const autoLogin = await UserClass.autoLoginUser();
    if( autoLogin === true ){
      this.setState( { showLoginScreen: false } );
    }

  }

  render() {

    if( this.state.isReady === false ){
      return (
        <AppLoading
          startAsync={ this.autoLoginUser }
          onFinish={ () => this.setState( { isReady: true } ) }
          onError={ () => this.setState( { isReady: true } ) }
        />
      );
    }

    return (
      <Provider store={ ReduxGlobals.store }>
        <View style={{ marginTop: 25 }}>
          { this.state.showLoginScreen ? <LoginView /> : <Text>APP</Text> }
        </View>
      </Provider>
    );
  }
}
