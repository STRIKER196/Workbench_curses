import React from 'react';
import { Text, View } from 'react-native';

import User from './src/Classes/User';


export default class App extends React.Component {
  state = {
    showLoginScreen: true
  };

  componentDidMount(){

    if( User.isUserLoggedIn() ){
      this.setState( { showLoginScreen: false } );
    }


  }

  render() {

    if( this.state.showLoginScreen === true ){
      return (
        <View>
          <Text>LOGIN</Text>
        </View>
      );
    }

    return (
      <View>
        <Text>APP</Text>
      </View>
    );
  }
}
