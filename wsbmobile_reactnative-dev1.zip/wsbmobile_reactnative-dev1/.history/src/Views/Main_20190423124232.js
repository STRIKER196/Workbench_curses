import React from 'react';
import { connect } from 'react-redux';
import { Text, TextInput, Button, View } from 'react-native';


class mainView extends React.Component {
  state = {
  };

  render() {
    return (
      <View>
        <Text>APP:</Text>


      </View>
    );
  }

}


const mapStateToProps = state => {
  return {
  }
}


export default connect( mapStateToProps )( mainView );