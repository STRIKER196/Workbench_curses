import React from 'react';
import { connect } from 'react-redux';
import { Text, TextInput, Button, View } from 'react-native';

import UserClass from '../Classes/User';

class mainView extends React.Component {
  state = {
  };

  render() {
    return (
      <View>
        <Text>APP:</Text>


        <Button
            style={{ marginTop: 20 }}
            onPress={ () => {
              console.log( "connectionCount: ", UserClass.Website.connectionCount() );
            } }
            title="Get Update"
        />
        <Button
            style={{ marginTop: 20 }}
            onPress={ () => {} }
            title="Log out"
        />

      </View>
    );
  }

}


const mapStateToProps = state => {
  return {
  }
}


export default connect( mapStateToProps )( mainView );