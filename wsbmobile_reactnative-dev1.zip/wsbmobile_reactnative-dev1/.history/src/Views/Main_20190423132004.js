import React from 'react';
import { connect } from 'react-redux';
import { Text, TextInput, TouchableOpacity, View } from 'react-native';

import UserClass from '../Classes/User';

class mainView extends React.Component {
  state = {
  };

  //TEMP
  updateTimetable = () => {
    
  }

  render() {
    return (
      <View>
        <Text>APP:</Text>


        <TouchableOpacity 
          onPress={ () => { console.log( "Connection Count: ", UserClass.Website.connectionCount() ); } }
          style={{ marginTop: 20, padding: 20, backgroundColor: '#adadad' }}>
          <Text>Get Connection Count</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          onPress={ () => { this.updateTimetable() } }
          style={{ marginTop: 20, padding: 20, backgroundColor: '#adadad' }}>
          <Text>Get Update</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          onPress={ () => {} }
          style={{ marginTop: 20, padding: 20, backgroundColor: '#adadad' }}>
          <Text>Log Out</Text>
        </TouchableOpacity>

      </View>
    );
  }

}


const mapStateToProps = state => {
  return {
  }
}


export default connect( mapStateToProps )( mainView );