import React from 'react';
import { connect } from 'react-redux';
import { Text, TextInput, TouchableOpacity, View } from 'react-native';

import UserClass from '../Classes/User';

//TEMP
import Update from '../Classes/Update/Update';
import TimetableUpdate from '../Classes/Update/TimetableUpdate';


class mainView extends React.Component {
  state = {
  };

  //TEMP
  updateTimetable = () => {
    console.log( "mainView updateTimetable - START:" );
    Update.update( new TimetableUpdate() );
    
  }

  render() {
    return (
      <View>
        <Text>APP:</Text>


        <TouchableOpacity 
          onPress={ () => { UserClass.Website.consoleLogConnection(); } }
          style={{ marginTop: 20, padding: 20, backgroundColor: '#adadad' }}>
          <Text>Get Connection Count</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          onPress={ () => { this.updateTimetable() } }
          style={{ marginTop: 20, padding: 20, backgroundColor: '#adadad' }}>
          <Text>Get Update</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          onPress={ () => { UserClass.logOutUser(); } }
          style={{ marginTop: 20, padding: 20, backgroundColor: '#adadad' }}>
          <Text>Log Out</Text>
        </TouchableOpacity>

      </View>
    );
  }

}


const mapStateToProps = state => {
  return {
  }
}


export default connect( mapStateToProps )( mainView );