import { createStore, combineReducers } from 'redux';

import UserReducers from '../Reducers/UserReducers';
import LoginReducers from '../Reducers/LoginReducers';


const initState = {
    //USER
    isUserLoggedIn: false,

    //LOGIN
    isLogginIn: false,
    logginMsg: '',
    logginMsgType: '',

};

class reduxGlobals{

    store = null;


    constructor(){
        this.store = createStore( combineReducers( {
            UserReducers,
            LoginReducers
        } ), initState );
    }

}

export default ( new reduxGlobals() );


