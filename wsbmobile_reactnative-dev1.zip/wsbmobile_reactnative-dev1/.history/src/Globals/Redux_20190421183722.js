import { createStore } from 'redux';

import UserReducers from '../Reducers/UserReducers';


const initState = {
    isUserLoggedIn: false
};

class reduxGlobals{

    store = null;


    constructor(){
        this.store = createStore( UserReducers, initState );
    }

}

export default ( new reduxGlobals() );


