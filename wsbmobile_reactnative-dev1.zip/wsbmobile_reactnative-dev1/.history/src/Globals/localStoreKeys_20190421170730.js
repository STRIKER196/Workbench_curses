
const keys = {
    USER_LOGIN,
    USER_PASSWORD
};

export default keys;