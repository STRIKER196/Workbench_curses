export const APPKEY = "WSBMOBILE:";


export const autoLogin = "AUTO-LOGIN-CREDENTIALS:";