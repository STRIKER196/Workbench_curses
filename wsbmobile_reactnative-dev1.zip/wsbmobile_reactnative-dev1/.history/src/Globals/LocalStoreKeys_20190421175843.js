
export const keys = {
    USER_LOGIN: 'USER_LOGIN',
    USER_PASSWORD: 'USER_PASSWORD'
};


export const AutoLoginKeys = {
    GET_CREDENTIALS: 'GET_CREDENTIALS'
};


