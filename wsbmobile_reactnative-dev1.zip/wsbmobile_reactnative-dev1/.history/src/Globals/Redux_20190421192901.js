import { createStore, combineReducers } from 'redux';

import UserReducers from '../Reducers/UserReducers';
import LoginReducers from '../Reducers/LoginReducers';


const initState = {
    isUserLoggedIn: false
};

class reduxGlobals{

    store = null;


    constructor(){
        this.store = createStore( combineReducers( {
            UserReducers,
            LoginReducers
        } ), initState );
    }

}

export default ( new reduxGlobals() );


