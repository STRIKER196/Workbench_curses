import { createStore, combineReducers } from 'redux';

import initState from './ReduxInitState';

import UserReducers from '../Reducers/UserReducers';
import LoginReducers from '../Reducers/LoginReducers';

class reduxGlobals{

    store = null;


    constructor(){
        const reducers = combineReducers( {
            user: UserReducers,
            login: LoginReducers
        } );
        this.store = createStore( reducers, initState );
    }

}

export default ( new reduxGlobals() );


