export const appKey = "WSBMOBILE:";


export const autoLogin = "AUTO-LOGIN-CREDENTIALS:";