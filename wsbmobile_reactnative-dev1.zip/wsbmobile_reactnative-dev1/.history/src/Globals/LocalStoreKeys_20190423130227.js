export const appKey = "WSBMOBILE:";


export const userCredentialsKey = "USER-CREDENTIALS:";