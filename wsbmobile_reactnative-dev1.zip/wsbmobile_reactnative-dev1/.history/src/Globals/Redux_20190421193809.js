import { createStore, combineReducers } from 'redux';

import UserReducers from '../Reducers/UserReducers';
import LoginReducers from '../Reducers/LoginReducers';


const initState = {
    //USER
    isUserLoggedIn: false,

    //LOGIN
    isLogginIn: false,
    logginMsg: '',
    logginMsgType: '',

};

class reduxGlobals{

    store = null;


    constructor(){
        const reducers = combineReducers( {
            user: UserReducers,
            login: LoginReducers
        } );
        this.store = createStore( reducers, initState );
    }

}

export default ( new reduxGlobals() );


