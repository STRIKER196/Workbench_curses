export const initStateLogin = {
    //USER
    isUserLoggedIn: false,

    //LOGIN
    isLogginIn: false,
    logginMsg: '',
    logginMsgType: '',

};

const initState = {
    //USER
    isUserLoggedIn: false,

    //LOGIN
    isLogginIn: false,
    logginMsg: '',
    logginMsgType: '',

};

