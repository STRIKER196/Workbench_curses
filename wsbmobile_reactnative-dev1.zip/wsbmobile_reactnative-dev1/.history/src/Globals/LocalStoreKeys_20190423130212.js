export const appKey = "WSBMOBILE:";


export const userCredentials = "USER-CREDENTIALS:";