export const initStateLogin = {
    isLogginIn: false,
    logginMsg: '',
    logginMsgType: '',

};
export const initStateUser = {
    isUserLoggedIn: false,
};


export const initState = () => { return { 
    ...initStateLogin, 
    ...initStateUser 
} };