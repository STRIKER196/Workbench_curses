export const APPKEY = "WSBMOBILE:";

