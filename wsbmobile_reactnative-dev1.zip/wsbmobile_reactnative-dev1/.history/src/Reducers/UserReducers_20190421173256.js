
const UserReducer = ( state, action ) => {

    return state;
};

export default UserReducer;
