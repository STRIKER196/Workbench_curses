
const UserReducer = ( state, action ) => {

    if( action.type === 'LOGIN_USER' ){
        return {
            ...state,
            user: action.data,
            isUserLoggedIn: true,
        };
    }

    return state;
};

export default UserReducer;
