import initStateUser from '../Globals/ReduxInitState';

const UserReducer = ( state = initStateUser, action ) => {

    if( action.type === 'SET_USER' ){
        return {
            ...state,
            user: action.data,
            isUserLoggedIn: true,
        };
    }

    return state;
};

export default UserReducer;
