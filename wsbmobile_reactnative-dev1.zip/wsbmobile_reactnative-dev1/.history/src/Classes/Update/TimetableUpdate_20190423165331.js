
import Website from '../Base/Website';


class TimetableUpdate{

    type = 'timetable';
    Website = null;

    constructor(){
        this.Website = new Website();
    }


    getHTML = async () => {

        const _type = this.type;
        this.Website.getPage( {
            'type': _type
        } );

    }




}

export default TimetableUpdate;