
import Website from '../Base/Website';
import UserClass from '../User';


class Update{

    Website = null;
    constructor(){
        this.Website = new Website();

    }

    update = async ( factory ) => {
        console.log( "\n\n--Update with factory " + factory.type );

        //Check session
        const session = await this.Website.checkSession();
        if( session === false ){

            //Login user
            const userCredentials = await UserClass.getUserCredentials();
            if( userCredentials === false ){
                return false;
            }

            return false;
        }
        console.log( "Session ok" );
        

        // //Get HTML from website
        // const html = factory.getHTML();

        // //Transform HTML to format that is used in local storage
        // const data = factory.transformToLocalStorageFormat( html );

    }


}

export default ( new Update() );