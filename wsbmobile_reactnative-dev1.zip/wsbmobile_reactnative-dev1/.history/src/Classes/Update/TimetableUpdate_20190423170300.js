
import Website from '../Base/Website';


class TimetableUpdate{

    type = 'timetable';
    Website = null;

    constructor(){
        this.Website = new Website();
    }


    getHTML = async () => {
        
        const _type = this.type;
        const page = this.Website.getPage( {
            'type': _type
        } );

        console.log( "TimetableUpdate getHTML - page: " );
        console.log( page );

        return page;
    }

    getDataFromHTML = async ( html ) => {

    }




}

export default TimetableUpdate;