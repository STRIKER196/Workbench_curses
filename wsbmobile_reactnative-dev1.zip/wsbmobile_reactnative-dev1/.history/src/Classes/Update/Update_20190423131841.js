

class Update{


    update = async () => {

        
    }


}

export default ( new Update() );