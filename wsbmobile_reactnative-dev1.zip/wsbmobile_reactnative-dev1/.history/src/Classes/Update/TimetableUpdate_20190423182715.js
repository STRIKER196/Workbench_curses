import fastHtmlParser from 'fast-html-parser';

import Website from '../Base/Website';


class TimetableUpdate{

    type = 'timetable';
    Website = null;

    constructor(){
        this.Website = new Website();
    }


    getHTML = async () => {
        const _type = this.type;
        const page = await this.Website.getPage( {
            'type': _type
        } );

        if( page === false ){
            return false;
        }

        //Cut page so the only thing left is inner <Table></Table>
        const index1 = page.indexOf( 'ctl00_ctl00_ContentPlaceHolder_RightContentPlaceHolder_dgDane' ) + 63;
        const index2 = page.indexOf( '</table>', index1 );

        const cutPage = page.substring( index1, index2 );
        return cutPage;
    }

    getDataFromHTML = async ( html ) => {

        const root = fastHtmlParser.parse( html );
        

        const data = [];
        let first = false;
        root.querySelector( 'tr' ).forEach( tr => {
            if( first === false ){
                first = true;
                return false;
            }

            tr.querySelector( 'td' ).forEach( td => {
                console.log( td );
            } );


        } );




        return null;
    }




}

export default TimetableUpdate;