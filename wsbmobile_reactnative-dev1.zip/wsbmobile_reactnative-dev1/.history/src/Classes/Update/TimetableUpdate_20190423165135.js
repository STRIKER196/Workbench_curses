
import Website from '../Base/Website';


class TimetableUpdate{

    type = 'timetable';
    Website = null;

    constructor(){
        this.Website = new Website();
    }


    getHTML = async () => {

        this.Website.getPage( {
            'timetable'
        } );

    }




}

export default TimetableUpdate;