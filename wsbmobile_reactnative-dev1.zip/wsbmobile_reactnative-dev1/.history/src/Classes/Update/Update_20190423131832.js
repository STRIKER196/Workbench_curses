

class Update{


    


}

export default ( new Update() );