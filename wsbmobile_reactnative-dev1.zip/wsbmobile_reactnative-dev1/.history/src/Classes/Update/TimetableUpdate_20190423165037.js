

class TimetableUpdate{

    type = 'timetable';



    getHTML = async () => {
        
    }




}

export default TimetableUpdate;