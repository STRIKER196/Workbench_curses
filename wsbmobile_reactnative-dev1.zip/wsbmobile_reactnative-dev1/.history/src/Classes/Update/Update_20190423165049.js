
import Website from '../Base/Website';
import UserClass from '../User';


class Update{

    Website = null;
    constructor(){
        this.Website = new Website();

    }

    checkSession = async () => {
        const session = await this.Website.checkSession();
        if( session === false ){
            console.log( "Session wrong, attempt to log in user" );

            //Login user, get credentials
            const userCredentials = await UserClass.getUserCredentials();
            if( userCredentials === false ){
                console.log( "No user credentials" );
                return false;
            }

            //Login user
            if( this.Website.logInUser( userCredentials ) === false ){
                console.log( "Cannot LogIn User!" );
                return false;
            }

        }

        console.log( "Session ok" );
        return true;
    }

    update = async ( factory ) => {
        console.log( "\n\n--Update with factory " + factory.type );

        if( this.checkSession() === false ){
            return false;
        }
        

        //Get HTML from website
        const html = factory.getHTML();
        console.log( "html: ", html );

        // //Transform HTML to format that is used in local storage
        // const data = factory.transformToLocalStorageFormat( html );

    }


}

export default ( new Update() );