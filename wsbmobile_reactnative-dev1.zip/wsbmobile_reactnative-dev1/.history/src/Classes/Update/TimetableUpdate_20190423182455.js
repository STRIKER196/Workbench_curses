import fastHtmlParser from 'fast-html-parser';

import Website from '../Base/Website';


class TimetableUpdate{

    type = 'timetable';
    Website = null;

    constructor(){
        this.Website = new Website();
    }


    getHTML = async () => {
        const _type = this.type;
        const page = await this.Website.getPage( {
            'type': _type
        } );

        if( page === false ){
            return false;
        }

        //Cut page so the only thing left is inner <Table></Table>
        const index1 = page.indexOf( 'ctl00_ctl00_ContentPlaceHolder_RightContentPlaceHolder_dgDane' ) + 63;
        const index2 = page.indexOf( '</table>', index1 );

        const cutPage = page.substring( index1, index2 );
        return cutPage;
    }

    getDataFromHTML = async ( html ) => {

        const root = fastHtmlParser.parse( html );
        
        let first = false;
        const data = root.querySelector( 'tr' ).childNodes.map( node => {
            if( first === false ){
                first = true;
                return false;
            }
        } );



        return null;
    }




}

export default TimetableUpdate;