

class TimetableUpdate{

    type = 'timetable';






}

export default TimetableUpdate;