

class TimetableUpdate{

    






}

export default TimetableUpdate;