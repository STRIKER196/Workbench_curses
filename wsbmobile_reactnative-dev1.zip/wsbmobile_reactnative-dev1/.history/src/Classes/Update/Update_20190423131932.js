

class Update{


    update = async ( args ) => {


    }


}

export default ( new Update() );