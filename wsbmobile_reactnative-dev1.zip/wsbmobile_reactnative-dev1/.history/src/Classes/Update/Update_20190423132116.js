

class Update{


    update = async ( factory ) => {


    }


}

export default ( new Update() );