import { AsyncStorage } from "react-native"

import axios from 'axios';
import parse5 from 'parse5';

// import Base from './Base/Base';
import Website from './Base/Website';

import { appKey, autoLoginKey } from '../Globals/LocalStoreKeys';
import reduxGlobals from '../Globals/Redux';


// function asyncSleep(ms) {
//     return new Promise(resolve => setTimeout(resolve, ms));
// }

// class userClass extends Base{
class userClass{

    constructor(){
        // super();

    }

    getUserAutoLogin = async () => {
        const autoLogin = {
            login: null,
            pass: null
        };

        autoLogin.login = await AsyncStorage.getItem( appKey + autoLoginKey + "login" );
        autoLogin.pass = await AsyncStorage.getItem( appKey + autoLoginKey + "pass" );

        if( autoLogin.login === null || autoLogin.pass === null ){
            return false;
        }

        return autoLogin;
    }

    logInUser = async ( userCredentials ) => {
        try{

            reduxGlobals.store.dispatch( { type: 'LOGIN_START' } );
            reduxGlobals.store.dispatch( { type: 'LOGIN_MSG_CLEAR' } );
            
            const logIn = Website.logInUser( userCredentials );
            
            //Check if login correct
            if( logIn === false ){
                //SET THAT LOGIN INCORRECT
                reduxGlobals.store.dispatch( { 
                    type: 'LOGIN_MSG',
                    msg: 'WRONG!',
                    msgType: 'danger' 
                } );
                reduxGlobals.store.dispatch( { type: 'LOGIN_END' } );
                return false;
            }

            reduxGlobals.store.dispatch( { type: 'LOGIN_MSG_CLEAR' } );
            reduxGlobals.store.dispatch( { type: 'LOGIN_END' } );
            

            //TODO: use Secure Storage
            //Save user to auto-login localstorage - setMultiItems
            await AsyncStorage.setItem( appKey + autoLoginKey + "login", userCredentials.login );
            await AsyncStorage.setItem( appKey + autoLoginKey + "pass", userCredentials.pass );

            //Save user to redux
            reduxGlobals.store.dispatch( {
                type: 'SET_USER',
                user: {
                    login: userCredentials.login
                }
            } );
            

            return true;

        }catch( error ){
            console.log( "ERROR - userClass logInUser:" );
            console.error( error );

            reduxGlobals.store.dispatch( { 
                type: 'LOGIN_MSG',
                msg: 'WRONG!',
                msgType: 'danger' 
            } );
            reduxGlobals.store.dispatch( { type: 'LOGIN_END' } );
        }
    }

    autoLoginUser = async () => {

        const autoLogin = this.getUserAutoLogin();
        if( autoLogin === false ){
            return false;
        }

        // const logInUser = await this.logInUser( autoLogin );
        // if( logInUser === false ){
        //     console.log( "userClass autoLoginUser - logInUser === false" );
        //     return false;
        // }

        return true;
    }



}

export default ( new userClass() );