import axios from 'axios';

import base from './Base/Base';
import keys from '../Globals/localStoreKeys';


class userClass extends base{

    constructor(){

    }


    isUserLoggedIn = () => {
        return false;
    }

}

export default ( new userClass() );