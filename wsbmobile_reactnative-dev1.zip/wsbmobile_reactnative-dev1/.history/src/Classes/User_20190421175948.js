import axios from 'axios';

import Base from './Base/Base';


// function asyncSleep(ms) {
//     return new Promise(resolve => setTimeout(resolve, ms));
// }

class userClass extends Base{

    constructor(){
        super();

    }

    autoLoginUser = async () => {

        const autoLogin = this.localStorage.get( {
            key: "AUTO-LOGIN-CREDENTIALS"
        } );

        // await asyncSleep( 2000 );







        return false;
    }



}

export default ( new userClass() );