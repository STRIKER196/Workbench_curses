

class userClass{

    

}

export default ( new userClass() );