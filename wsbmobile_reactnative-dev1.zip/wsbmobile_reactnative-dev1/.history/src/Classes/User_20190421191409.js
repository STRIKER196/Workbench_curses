import { AsyncStorage } from "react-native"

import axios from 'axios';
import parse5 from 'parse5';

import Base from './Base/Base';

import { appKey, autoLogin } from '../Globals/LocalStoreKeys';
import reduxGlobals from '../Globals/Redux';


// function asyncSleep(ms) {
//     return new Promise(resolve => setTimeout(resolve, ms));
// }

class userClass extends Base{

    constructor(){
        super();

    }

    logInUser = async ( userCredentials ) => {
        const loginUrl = 'https://wu.wsb.edu.pl/wu/Logowanie2.aspx';

        const conFirst = await axios.get( loginUrl );
        const ast = parse5.parse( conFirst.data );
        console.log( "userClass logInUser - ast:" );
        console.log( ast );
        



    }

    autoLoginUser = async () => {

        const autoLogin = {
            login: null,
            pass: null
        };

        //Promise.ALL(?)
        autoLogin.login = await AsyncStorage.getItem( appKey + autoLogin + "login" );
        autoLogin.pass = await AsyncStorage.getItem( appKey + autoLogin + "pass" );

        if( autoLogin.login === null || autoLogin.pass === null ){
            console.log( "userClass autoLoginUser - login/pass === null" );
            return false;
        }

        const logInUser = this.logInUser( autoLogin );
        if( logInUser === false ){
            console.log( "userClass autoLoginUser - logInUser === false" );
            return false;
        }

        return true;
    }



}

export default ( new userClass() );