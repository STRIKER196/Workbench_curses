import { AsyncStorage } from "react-native"

import axios from 'axios';


import Base from './Base/Base';
import { appKey, autoLogin } from '../Globals/LocalStoreKeys';


// function asyncSleep(ms) {
//     return new Promise(resolve => setTimeout(resolve, ms));
// }

class userClass extends Base{

    constructor(){
        super();

    }

    autoLoginUser = async () => {

        const autoLogin = {
            login: null,
            pass: null
        };

        //Promise.ALL(?)
        autoLogin.login = await AsyncStorage.getItem( appKey + autoLogin + "login" );
        autoLogin.pass = await AsyncStorage.getItem( appKey + autoLogin + "pass" );

        if( autoLogin.login === null || autoLogin.pass === null ){
            return false;
        }


        //LOG IN USER
        





        return false;
    }



}

export default ( new userClass() );