// import reduxWrapper from './StateManager/Redux';
import localStorage from './LocalStorage';

export default class baseClass{
    type = 'base';

    localStorage = null;
    reduxWrapper = null;

    constructor(){
        super();
        this.localStorage = new localStorage();

    }

}

