import { AsyncStorage } from "react-native"

export default class localStorage{

    
    get = ( args ) => {
        // try{
        //     const value = await AsyncStorage.getItem( args.key );
        //     return value;

        // }catch( error ){
            
        // }
    }
    

}


