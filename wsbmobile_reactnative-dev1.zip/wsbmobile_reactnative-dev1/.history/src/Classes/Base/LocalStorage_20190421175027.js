
export default class localStorage{

    
    get = ( args ) => {

        

    }
    

}


