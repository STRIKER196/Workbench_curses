
export default class localStorage{

    _ls_typeToObj = ( type ) => {
        let obj = null;
        switch( type )
        {
            case "timetable": obj = _TIMETABLE; break;
            case "marks": obj = _MARKS; break;
            default: return null;
        }
        return obj;
    }

    _getLocalStorage = ( args = {} ) => {
        const { keys, type } = args;
        const search = this._ls_typeToObj( type );
        const toReturn = {};

        //Return all if needed
        if( 'get-all' in args && args['get-all'] === true )
            return search;

        keys.forEach( key => {
            if( key in search )
                toReturn[key] = search[key];
        } );

        return toReturn;
    }

    _setLocalStorage = ( args = {} ) => {
        console.log( "\nlocalStorage _setLocalStorage()" );
        console.log( args );

        const { type, data } = args;
        const search = this._ls_typeToObj( type );

        Object.keys( data ).forEach( key => {
            search[key] = data[key];
        } );

        console.log( search );

    }


}


