import axios from 'axios';

import Base from './Base/Base';
// import keys from '../Globals/LocalStoreKeys';


class userClass extends Base{

    constructor(){
        super();

    }


    isUserLoggedIn = () => {



        return false;
    }

}

export default ( new userClass() );