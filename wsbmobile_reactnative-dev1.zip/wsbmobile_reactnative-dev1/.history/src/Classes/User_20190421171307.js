import axios from 'axios';
import keys from '../Globals/localStoreKeys';

class userClass{


    

    isUserLoggedIn = () => {
        return false;
    }

}

export default ( new userClass() );