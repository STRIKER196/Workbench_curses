import { AsyncStorage } from "react-native"

import axios from 'axios';
import parse5 from 'parse5';

import Base from './Base/Base';

import { appKey, autoLogin } from '../Globals/LocalStoreKeys';
import reduxGlobals from '../Globals/Redux';


// function asyncSleep(ms) {
//     return new Promise(resolve => setTimeout(resolve, ms));
// }

class userClass extends Base{

    constructor(){
        super();

    }

    logInUser = async ( userCredentials ) => {
        try{

            //SET THAT LOGIN IN PROGRESS
            
            const loginUrl = 'https://wu.wsb.edu.pl/wu/Logowanie2.aspx';

            const conFirst = await axios.get( loginUrl );
            const ast = parse5.parse( conFirst.data );

            const formObj = ast['childNodes'][0]['childNodes'][1]['childNodes'][17]['childNodes'];
            const viewState = encodeURI( formObj[1]['attrs'][3]['value'] );
            
            const dataObj = {
                "__EVENTTARGET": "",
                "__EVENTARGUMENT": "",
                // "__LASTFOCUS": "__LASTFOCUS",
                "__VIEWSTATE": viewState,
                // "__EVENTVALIDATION": "__EVENTVALIDATION",
        
                "ctl00_ctl00_TopMenuPlaceHolder_TopMenuContentPlaceHolder_MenuTop3_menuTop3_ClientState": "__EVENTTARGET",
                "ctl00_ctl00_ScriptManager1_HiddenField": "__EVENTTARGET",

                "ctl00$ctl00$ContentPlaceHolder$MiddleContentPlaceHolder$txtIdent": userCredentials.login,
                "ctl00$ctl00$ContentPlaceHolder$MiddleContentPlaceHolder$txtHaslo": userCredentials.pass,
                "ctl00$ctl00$ContentPlaceHolder$MiddleContentPlaceHolder$butLoguj": "Zaloguj",
                "ctl00$ctl00$ContentPlaceHolder$MiddleContentPlaceHolder$rbKto": "student",
            };

            const formData = new FormData();
            Object.keys( dataObj ).forEach( key => {
                formData.append( key, dataObj[key] );
            } );

            const conSecond = await axios.post( loginUrl, formData );

            //conSecond.headers.set-cookie: ".ASPXUSERWU="

            //Check if login correct
            if( conSecond.headers['set-cookie'].indexOf( '.ASPXUSERWU=' ) === -1 ){
                //SET THAT LOGIN INCORRECT
                return false;
            }

            //Save user to redux
            reduxGlobals.store.dispatch( {
                type: 'SET_USER',
                user: {
                    login: userCredentials.login,
                    pass: userCredentials.pass,
                }
            } );

            //Save user to auto-login localstorage
            

            return true;

        }catch( error ){
            console.log( "ERROR - userClass logInUser:" );
            console.error( error );
        }
    }

    autoLoginUser = async () => {

        const autoLogin = {
            login: null,
            pass: null
        };

        //Promise.ALL(?)
        autoLogin.login = await AsyncStorage.getItem( appKey + autoLogin + "login" );
        autoLogin.pass = await AsyncStorage.getItem( appKey + autoLogin + "pass" );

        if( autoLogin.login === null || autoLogin.pass === null ){
            console.log( "userClass autoLoginUser - login/pass === null" );
            return false;
        }

        const logInUser = this.logInUser( autoLogin );
        if( logInUser === false ){
            console.log( "userClass autoLoginUser - logInUser === false" );
            return false;
        }

        return true;
    }



}

export default ( new userClass() );