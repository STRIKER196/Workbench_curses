import axios from 'axios';

import Base from './Base/Base';
// import keys from '../Globals/LocalStoreKeys';


class userClass extends Base{

    constructor(){
        super();

    }

    isUserLoggedIn = () => {

        const autoLogin = this.getAutoLoginCredentials();



        return false;
    }


    getUserCredentials = () => {

        this.localStorage.get( {
            key: 'auto-login-user-credentials'
        } );

    }

}

export default ( new userClass() );