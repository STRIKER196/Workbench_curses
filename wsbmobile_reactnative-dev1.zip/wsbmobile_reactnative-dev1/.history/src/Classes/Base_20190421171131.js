import aggregation from '../Lib/aggregation';

// import reduxWrapper from './StateManager/Redux';
import localStorage from './LocalStorage';


// export default class baseClass extends aggregation( reduxWrapper, localStorage ){
export default class baseClass extends aggregation( localStorage ){
    type = 'base';

}

