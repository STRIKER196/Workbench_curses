

const _TIMETABLE = {
    "18.03.2019;24.03.2019" : {
        "20.03.2019" : {
            "day-name" : "Sroda",
            "lessons" : [
                { "id": 1, "lesson": "Angielski",  "start": "11:00", "end": "12:30" },
                { "id": 2, "lesson": "PBL",  "start": "12:40", "end": "14:10" }
            ]
        },
        "21.03.2019" : {
            "day-name" : "Czwartek",
            "lessons" : [
                { "id": 1, "lesson": "Programowanie Obiektowe",  "start": "11:00", "end": "12:30" },
            ]
        },
        "22.03.2019" : {
            "day-name" : "Piatek",
            "lessons" : [
                { "id": 1, "lesson": "Automatyka",  "start": "11:00", "end": "12:30" },
            ]
        }
    }
};
const _MARKS = {
    "Angielski": {
        "Lektorat" : {
            "mark": ''
        }
    },
    "PBL": {
        "Cwiczenia" : {
            "mark": 4
        }
    },
    "Automatyka": {
        "Wykład": {
            "mark": 3
        },
        "Ćwiczenia" : {
            "mark": 3
        }
    }
};
// const _OPTIONS = {

// };


export default class localStorage{

    _ls_typeToObj = ( type ) => {
        let obj = null;
        switch( type )
        {
            case "timetable": obj = _TIMETABLE; break;
            case "marks": obj = _MARKS; break;
            default: return null;
        }
        return obj;
    }

    _getLocalStorage = ( args = {} ) => {
        const { keys, type } = args;
        const search = this._ls_typeToObj( type );
        const toReturn = {};

        //Return all if needed
        if( 'get-all' in args && args['get-all'] === true )
            return search;

        keys.forEach( key => {
            if( key in search )
                toReturn[key] = search[key];
        } );

        return toReturn;
    }

    _setLocalStorage = ( args = {} ) => {
        console.log( "\nlocalStorage _setLocalStorage()" );
        console.log( args );

        const { type, data } = args;
        const search = this._ls_typeToObj( type );

        Object.keys( data ).forEach( key => {
            search[key] = data[key];
        } );

        console.log( search );

    }


}


