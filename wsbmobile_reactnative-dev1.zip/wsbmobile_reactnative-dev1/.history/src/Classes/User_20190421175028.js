import axios from 'axios';

import Base from './Base/Base';
// import keys from '../Globals/LocalStoreKeys';


class userClass extends Base{

    constructor(){
        super();

    }

    autoLoginUser = () => {
        
        const autoLogin = this.localStorage.get( {
            key: 'auto-login-user-credentials'
        } );





        return false;
    }



}

export default ( new userClass() );