

class userClass{


    isUserLoggedIn = () => {
        return false;
    }

}

export default ( new userClass() );