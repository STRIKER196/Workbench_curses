import React from 'react';
import { connect } from 'react-redux';

import { Text, View } from 'react-native';
import { AppLoading } from 'expo';

import ReduxGlobals from './Globals/Redux';
import UserClass from './Classes/User';

import LoginView from './Views/Login';
import MainView from './Views/Main';


class App extends React.Component {
  state = {
    isReady: false,
    // showLoginScreen: true,
  };

  autoLoginUser = async () => {
    await UserClass.setUserBasedOnAutoLogin();
    
  }

  render() {

    if( this.state.isReady === false ){
      return (
        <AppLoading
          startAsync={ this.autoLoginUser }
          onFinish={ () => this.setState( { isReady: true } ) }
          onError={ () => this.setState( { isReady: true } ) }
        />
      );
    }

    return (
        <View style={{ marginTop: 25 }}>
            { !this.props.isUserLoggedIn ? <LoginView /> : <MainView /> }
        </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    isUserLoggedIn: state.user.isUserLoggedIn
  }
}

export default connect( mapStateToProps )( App );