import React from 'react';
import { createStore } from 'redux';
import { connect } from 'react-redux';

import { Text, View } from 'react-native';
import { AppLoading } from 'expo';

import ReduxGlobals from './Globals/Redux';

import UserClass from './Classes/User';
import LoginView from './Views/Login';


export default class App extends React.Component {
  state = {
    isReady: false,
    isUserLoggedIn: false,
    // showLoginScreen: true,
  };

  autoLoginUser = async () => {

    const autoLogin = await UserClass.autoLoginUser();
    if( autoLogin === true ){
      // this.setState( { showLoginScreen: false } );
    }

  }

  render() {

    if( this.state.isReady === false ){
      return (
        <AppLoading
          startAsync={ this.autoLoginUser }
          onFinish={ () => this.setState( { isReady: true } ) }
          onError={ () => this.setState( { isReady: true } ) }
        />
      );
    }

    return (
        <View style={{ marginTop: 25 }}>
            { !this.state.isUserLoggedIn ? <LoginView /> : <Text>APP</Text> }
        </View>
    );
  }
}

// const mapStateToProps = state => {
//   console.log( state );
//   return {
//     isUserLoggedIn: state.isUserLoggedIn
//   }
// }

// export default connect( mapStateToProps )( App );