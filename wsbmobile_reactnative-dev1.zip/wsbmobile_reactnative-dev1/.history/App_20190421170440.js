import React from 'react';
import { Text, View } from 'react-native';

import Login from './src/Classes/User';


export default class App extends React.Component {
  state = {
    showLoginScreen: true
  };

  componentDidMount(){

  }

  render() {

    if( this.state.showLoginScreen === true ){
      return (
        <View>
          <Text>LOGIN</Text>
        </View>
      );
    }

    return (
      <View>
        <Text>APP</Text>
      </View>
    );
  }
}
