import React from 'react';
import { Text, View } from 'react-native';



export default class App extends React.Component {
  state = {
    showLoginScreen: true
  };

  render() {

    if( this.state.showLoginScreen === true ){
      return (
        <View>
          <Text>LOGIN</Text>
        </View>
      );
    }

    return (
      <View>
        <Text>APP</Text>
      </View>
    );
  }
}
