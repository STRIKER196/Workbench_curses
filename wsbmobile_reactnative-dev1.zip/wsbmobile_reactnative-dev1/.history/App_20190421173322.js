import React from 'react';
import { createStore } from 'redux';
import { connect, Provider } from 'react-redux';

import { Text, View } from 'react-native';


import ReduxGlobals from './src/Globals/Redux';

import User from './src/Classes/User';

import LoginView from './src/Views/Login';


export default class App extends React.Component {
  state = {
    showLoginScreen: true
  };

  componentDidMount(){

    if( User.isUserLoggedIn() ){
      this.setState( { showLoginScreen: false } );
    }

  }

  render() {
    return (
      <Provider store={ ReduxGlobals.store }>
        <View style={{ marginTop: 25 }}>
          { this.state.showLoginScreen ? <LoginView /> : <Text>APP</Text> }
        </View>
      </Provider>
    );
  }
}
